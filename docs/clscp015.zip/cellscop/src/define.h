
#define UM_DlgRuleApply 12456
#define UM_DlgRuleSum0  2000
#define UM_DlgRuleSum1  2001
#define UM_DlgRuleSum2  2002
#define UM_DlgRuleSum3  2003
#define UM_DlgRuleSum4  2004
#define UM_DlgRuleSum5  2005
#define UM_DlgRuleSum6  2006
#define UM_DlgRuleSum7  2007
#define UM_DlgRuleSum8  2008
#define UM_DlgRuleSum9  2009
